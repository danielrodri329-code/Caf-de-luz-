// Escribir aqui el código Javascript// ============================================================
// CAFÉ DE LUZ — APP COMPLETA
// 9 mesas · Submenús por categoría · Edición de precios
// ============================================================

const MENU_INICIAL = [
{
cat: “☕ Bebidas Calientes”, ico: “☕”, editable: false,
items: [
{ n: “Expresso”, p: 5000 },
{ n: “Americano”, p: 3000 },
{ n: “Americano Premium Orgánico”, p: 6000 },
{ n: “Café Vietnamita”, p: 6000 },
{ n: “Café en leche”, p: 3500 },
{ n: “Café campesino”, p: 4000 },
{ n: “Café latte”, p: 3500 },
{ n: “Capuchino”, p: 7000 },
{ n: “Mocachino”, p: 8000 },
{ n: “Milo caliente”, p: 7000 },
{ n: “Avena caliente”, p: 8000 },
{ n: “Chocolate con queso”, p: 8000 },
{ n: “Agua panela con queso”, p: 9000 },
{ n: “Mazamorra de dulce”, p: 9000 },
]
},
{
cat: “🥃 Calientes con Licor”, ico: “🥃”, editable: false,
items: [
{ n: “Vino caliente”, p: 16000 },
{ n: “Capuchino Baileys”, p: 9000 },
{ n: “Canelazo”, p: 7000 },
{ n: “Carajillo”, p: 7000 },
]
},
{
cat: “🧊 Bebidas Frías”, ico: “🧊”, editable: false,
items: [
{ n: “Café granizado (Agua)”, p: 9000 },
{ n: “Café granizado (Leche)”, p: 9000 },
{ n: “Té granizado”, p: 9000 },
{ n: “Milo granizado”, p: 9000 },
{ n: “Avena helada”, p: 11000 },
{ n: “Hojitcha”, p: 11000 },
{ n: “Frozen Vainilla”, p: 11000 },
{ n: “Frozen Capuchino”, p: 11000 },
{ n: “Frozen Moka”, p: 9000 },
{ n: “Shakerato de limón”, p: 12000 },
{ n: “Malteada Vainilla”, p: 10000 },
{ n: “Malteada Chocolate”, p: 8000 },
{ n: “Malteada Brownie”, p: 10000 },
{ n: “Malteada Jumbo”, p: 10000 },
{ n: “Maracucoco”, p: 10000 },
{ n: “Limonada natural”, p: 7000 },
{ n: “Limonada de coco”, p: 8000 },
{ n: “Limonada cerezada”, p: 8000 },
{ n: “Limonada de hierbabuena”, p: 8000 },
{ n: “Jugos naturales (agua)”, p: 7000 },
{ n: “Jugos naturales (granizados)”, p: 8000 },
{ n: “Jugos naturales (leche)”, p: 8000 },
]
},
{
cat: “🍹 Frías con Licor”, ico: “🍹”, editable: false,
items: [
{ n: “Frozen Baileys”, p: 12500 },
{ n: “Café Granizado Baileys”, p: 11000 },
{ n: “Malteadas Baileys”, p: 12500 },
{ n: “Shakerato Boyacense”, p: 10000 },
{ n: “Micheladas”, p: 8000 },
]
},
{
cat: “🌿 Aromáticas”, ico: “🌿”, editable: false,
items: [
{ n: “Aromática de hierbas”, p: 3000 },
{ n: “Aromática de frutas”, p: 3500 },
]
},
{
cat: “🍽️ Comidas”, ico: “🍽️”, editable: false,
items: [
{ n: “Desayunos”, p: 15000 },
{ n: “Ensalada de frutas”, p: 12000 },
{ n: “Banana Split”, p: 12000 },
{ n: “Salpicón”, p: 8000 },
{ n: “Salpicón con helado”, p: 11000 },
{ n: “Empanadas”, p: 3000 },
{ n: “Torta de chocolate”, p: 4500 },
{ n: “Torta de café”, p: 4500 },
{ n: “Torta de zanahoria”, p: 4500 },
{ n: “Brownie con helado”, p: 9000 },
{ n: “Queso con arequipe”, p: 8000 },
{ n: “Papas de paquete”, p: 3000 },
{ n: “Galletas hojaldre”, p: 5000 },
{ n: “Galletas de avena”, p: 1500 },
]
},
{
cat: “🍦 Helados”, ico: “🍦”, editable: false,
items: [
{ n: “Helado de cono”, p: 3500 },
{ n: “Paleta de agua”, p: 3000 },
{ n: “Tosh”, p: 4500 },
{ n: “Choco Cono”, p: 4000 },
{ n: “Artesanal”, p: 4500 },
{ n: “Bocatto”, p: 7000 },
{ n: “Drácula”, p: 6000 },
{ n: “Casero”, p: 3000 },
{ n: “Aloja Raspao”, p: 7000 },
{ n: “Polet”, p: 6000 },
{ n: “Tosh Pasión”, p: 5000 },
{ n: “Jet”, p: 5000 },
{ n: “Chocolisto”, p: 3000 },
]
},
{
cat: “🍺 Licores y Cervezas”, ico: “🍺”, editable: false,
items: [
{ n: “Shots de aguardiente”, p: 5000 },
{ n: “Cerveza Nacional”, p: 5000 },
{ n: “Cerveza Bruder”, p: 7000 },
]
},
{
cat: “🥤 Postobón y Más”, ico: “🥤”, editable: true,
items: [
{ n: “Coca-Cola”, p: 3000 },
{ n: “Postobón Manzana”, p: 2500 },
{ n: “Postobón Uva”, p: 2500 },
{ n: “Postobón Naranja”, p: 2500 },
{ n: “Postobón Hit”, p: 2500 },
{ n: “Agua mineral”, p: 2000 },
{ n: “Paletas de Arándano”, p: 3000 },
]
},
];

// ── ESTADO ──────────────────────────────────────────────────
function estadoInicial() {
return {
mesas: Object.fromEntries([1,2,3,4,5,6,7,8,9].map(m => [m, []])),
historial: [],
menu: JSON.parse(JSON.stringify(MENU_INICIAL)),
};
}

function cargar() {
try {
const s = localStorage.getItem(‘cdl_v2’);
if (s) {
const d = JSON.parse(s);
// ensure all 9 mesas exist
for (let m = 1; m <= 9; m++) { if (!d.mesas[m]) d.mesas[m] = []; }
return d;
}
} catch(e) {}
return estadoInicial();
}

function guardar() { localStorage.setItem(‘cdl_v2’, JSON.stringify(state)); }

let state = cargar();
let mesaActiva = 1;
let catActiva = null;
let editandoCat = null, editandoIdx = null;
let nuevoCat = null;
let histFiltro = ‘hoy’;

// ── UTILIDADES ───────────────────────────────────────────────
const $ = id => document.getElementById(id);

function fmt(n) {
if (!n && n !== 0) return ‘$0’;
return ‘$’ + Math.round(n).toLocaleString(‘es-CO’);
}

function fechaHoy() {
return new Date().toLocaleDateString(‘es-CO’, { weekday:‘long’, year:‘numeric’, month:‘long’, day:‘numeric’ });
}

function hora() {
return new Date().toLocaleTimeString(‘es-CO’, { hour:‘2-digit’, minute:‘2-digit’ });
}

function dKey(d) {
const dd = d || new Date();
return dd.toISOString().split(‘T’)[0];
}

function showToast(msg, ms=2200) {
const t = $(‘toast’);
t.textContent = msg;
t.classList.add(‘show’);
setTimeout(() => t.classList.remove(‘show’), ms);
}

function cerrarModal(id) { $(id).classList.remove(‘open’); }

function overlayClick(e, id) { if (e.target === $(id)) cerrarModal(id); }

// ── NAVEGACIÓN ───────────────────────────────────────────────
function irA(screen) {
document.querySelectorAll(’.screen’).forEach(s => s.classList.remove(‘active’));
$(‘screen-’ + screen).classList.add(‘active’);
if (screen === ‘selector’) renderSelector();
else if (screen === ‘dashboard’) renderDashboard();
else if (screen === ‘historial’) renderHistorial(‘hoy’);
else if (screen === ‘configuracion’) renderConfig();
}

function volverSelector() { irA(‘selector’); }

// ── PANTALLA SELECTOR ────────────────────────────────────────
function renderSelector() {
const grid = $(‘mesasGrid’);
grid.innerHTML = ‘’;
for (let m = 1; m <= 9; m++) {
const pedido = state.mesas[m] || [];
const total = totalMesa(m);
const activa = pedido.length > 0;
const div = document.createElement(‘div’);
div.className = ‘mesa-tile’ + (activa ? ’ activa’ : ‘’);
div.innerHTML = `${activa ?`<div class="mesa-tile-badge">${pedido.length}</div>`: ''} <div class="mesa-tile-icon">${activa ? '🪑' : '⬜'}</div> <div class="mesa-tile-name">Mesa ${m}</div> ${activa ?`<div class="mesa-tile-total">${fmt(total)}</div>`: '<div class="mesa-tile-total" style="color:#3a3428;font-size:10px">Libre</div>'}`;
div.onclick = () => abrirMesa(m);
grid.appendChild(div);
}
}

// ── PANTALLA MESA ────────────────────────────────────────────
function abrirMesa(m) {
mesaActiva = m;
catActiva = null;
$(‘mesaTopName’).textContent = ’Mesa ’ + m;
irA(‘mesa’);
renderCatList();
$(‘submenuArea’).innerHTML = ‘<div class="submenu-placeholder">← Selecciona una categoría</div>’;
renderOrder();
}

function renderCatList() {
const list = $(‘catList’);
list.innerHTML = ‘’;
state.menu.forEach((cat, ci) => {
const div = document.createElement(‘div’);
div.className = ‘cat-item’ + (catActiva === ci ? ’ selected’ : ‘’);
div.innerHTML = `<span><span class="cat-item-ico">${cat.ico}</span>${cat.cat.replace(/^.{1,2}\s/, '')}</span> <span class="cat-item-arrow">›</span>`;
div.onclick = () => seleccionarCat(ci);
list.appendChild(div);
});
}

function seleccionarCat(ci) {
catActiva = ci;
renderCatList();
renderSubmenu(ci);
}

function renderSubmenu(ci) {
const cat = state.menu[ci];
const area = $(‘submenuArea’);
if (!cat || cat.items.length === 0) {
area.innerHTML = ‘<div class="submenu-placeholder">Sin productos en esta categoría</div>’;
return;
}
area.innerHTML = cat.items.map((it, ii) => `<div class="submenu-item"> <div class="submenu-item-left"> <div class="submenu-item-name">${it.n}</div> <div class="submenu-item-price">${fmt(it.p)}</div> </div> <button class="submenu-add-btn" onclick="agregarItem(${ci},${ii})">+</button> </div>`).join(’’);
}

function agregarItem(ci, ii) {
const it = state.menu[ci].items[ii];
const pedido = state.mesas[mesaActiva];
const existe = pedido.find(x => x.n === it.n);
if (existe) { existe.qty++; }
else { pedido.push({ n: it.n, p: it.p, qty: 1 }); }
guardar();
renderOrder();
// brief flash on button
showToast(’✓ ’ + it.n);
}

function renderOrder() {
const pedido = state.mesas[mesaActiva] || [];
const total = totalMesa(mesaActiva);
const count = pedido.reduce((s, i) => s + i.qty, 0);

$(‘mesaTopCount’).textContent = count + (count === 1 ? ’ ítem’ : ’ ítems’);
$(‘orderTotalNum’).textContent = fmt(total);

const hasPedido = pedido.length > 0;
$(‘cobrarBtnTop’).classList.toggle(‘activo’, hasPedido);
$(‘cobrarBtnMain’).classList.toggle(‘activo’, hasPedido);
$(‘cobrarBtnMain’).textContent = hasPedido ? `💰 Cobrar — ${fmt(total)}` : ‘💰 Cobrar’;

const list = $(‘orderList’);
if (pedido.length === 0) {
list.innerHTML = ‘<div class="order-empty"><span>🍽️</span><br>Sin productos</div>’;
return;
}
list.innerHTML = pedido.map((it, idx) => `<div class="order-item"> <div class="order-item-top"> <div class="order-item-name">${it.n}</div> <button class="order-item-del" onclick="eliminarItem(${idx})">✕</button> </div> <div class="order-item-bottom"> <div class="order-item-qty-ctrl"> <button class="qty-minus" onclick="cambiarQty(${idx},-1)">−</button> <span class="qty-num">${it.qty}</span> <button class="qty-plus" onclick="cambiarQty(${idx},1)">+</button> </div> <div class="order-item-sub">${fmt(it.p * it.qty)}</div> </div> </div>`).join(’’);
}

function cambiarQty(idx, delta) {
const pedido = state.mesas[mesaActiva];
pedido[idx].qty = Math.max(1, pedido[idx].qty + delta);
guardar();
renderOrder();
}

function eliminarItem(idx) {
state.mesas[mesaActiva].splice(idx, 1);
guardar();
renderOrder();
showToast(‘🗑️ Eliminado’);
}

function limpiarMesa() {
if (state.mesas[mesaActiva].length === 0) return;
if (!confirm(’¿Limpiar Mesa ’ + mesaActiva + ’ sin registrar cobro?’)) return;
state.mesas[mesaActiva] = [];
guardar();
renderOrder();
showToast(‘Mesa limpiada’);
}

function totalMesa(m) {
return (state.mesas[m] || []).reduce((s, i) => s + i.p * i.qty, 0);
}

// ── COBRO ────────────────────────────────────────────────────
function abrirCobro() {
const pedido = state.mesas[mesaActiva];
if (!pedido || pedido.length === 0) { showToast(‘⚠️ Mesa vacía’); return; }
const total = totalMesa(mesaActiva);
$(‘cobroTitle’).textContent = ‘Cobrar Mesa ’ + mesaActiva;
$(‘cobroSub’).textContent = pedido.length + ’ producto(s) · ’ + hora();
$(‘cobroMonto’).textContent = fmt(total);
$(‘cobroItems’).innerHTML = pedido.map(it =>
`<div class="cobro-item-row"><span>${it.qty}× ${it.n}</span><span>${fmt(it.p * it.qty)}</span></div>`
).join(’’);
$(‘btnConfirmar’).onclick = confirmarCobro;
$(‘modalCobro’).classList.add(‘open’);
}

function confirmarCobro() {
const pedido = state.mesas[mesaActiva];
const total = totalMesa(mesaActiva);
state.historial.push({
mesa: mesaActiva,
fecha: dKey(),
hora: hora(),
total,
items: pedido.map(i => ({ …i })),
});
state.mesas[mesaActiva] = [];
guardar();
cerrarModal(‘modalCobro’);
renderOrder();
showToast(’✅ ’ + fmt(total) + ’ cobrado — Mesa ’ + mesaActiva, 2800);
}

// ── DASHBOARD ────────────────────────────────────────────────
function renderDashboard() {
const hoy = dKey();
const ventasHoy = state.historial.filter(h => h.fecha === hoy);
const totalHoy = ventasHoy.reduce((s, h) => s + h.total, 0);
const totalAcum = state.historial.reduce((s, h) => s + h.total, 0);
let enCurso = 0, mesasActivas = 0;
for (let m = 1; m <= 9; m++) { const t = totalMesa(m); if (t > 0) { enCurso += t; mesasActivas++; } }

const mesasHTML = Array.from({length:9}, (_,i) => {
const m = i+1, t = totalMesa(m), act = t > 0;
return `<div class="dash-mesa-card${act?' activa':''}" onclick="abrirMesa(${m});irA('mesa')"> <div class="dash-mesa-num">Mesa ${m}</div> ${act ? `<div class="dash-mesa-tot">${fmt(t)}</div>` : '<div style="font-size:10px;color:#3a3428;margin-top:3px">Libre</div>'} </div>`;
}).join(’’);

const recientes = […state.historial].reverse().slice(0, 6);
const recHTML = recientes.length === 0
? ‘<div class="empty-state"><div class="ei">📭</div><p>Sin ventas registradas aún</p></div>’
: recientes.map(h => ` <div class="venta-card"> <div class="venta-card-head"> <div><div class="venta-mesa-tag">Mesa ${h.mesa}</div><div class="venta-time">${h.fecha} · ${h.hora}</div></div> <div class="venta-monto">${fmt(h.total)}</div> </div> <div class="venta-desc">${h.items.length} producto(s)</div> </div>`).join(’’);

$(‘dashBody’).innerHTML = `<div class="dash-stats"> <div class="dash-stat featured"> <div class="dash-stat-label">Ventas hoy</div> <div class="dash-stat-val">${fmt(totalHoy)}</div> <div class="dash-stat-sub">${ventasHoy.length} cobros</div> </div> <div class="dash-stat"> <div class="dash-stat-label">Mesas activas</div> <div class="dash-stat-val">${mesasActivas}</div> <div class="dash-stat-sub">de 9 mesas</div> </div> <div class="dash-stat"> <div class="dash-stat-label">En curso</div> <div class="dash-stat-val">${fmt(enCurso)}</div> <div class="dash-stat-sub">sin cobrar</div> </div> <div class="dash-stat"> <div class="dash-stat-label">Total histórico</div> <div class="dash-stat-val">${fmt(totalAcum)}</div> <div class="dash-stat-sub">${state.historial.length} ventas</div> </div> </div> <div class="section-sep">Estado de mesas</div> <div class="dash-mesas-grid">${mesasHTML}</div> <div class="section-sep">Últimas ventas</div> ${recHTML}`;
}

// ── HISTORIAL ────────────────────────────────────────────────
function renderHistorial(filtro) {
histFiltro = filtro;
// Filters bar
const filtros = [
{k:‘hoy’, l:‘Hoy’}, {k:‘semana’, l:‘Semana’}, {k:‘todo’, l:‘Todo’},
…Array.from({length:9}, (_,i) => ({k:‘mesa’+(i+1), l:‘Mesa ‘+(i+1)}))
];
$(‘histFilters’).innerHTML = filtros.map(f =>
`<button class="hfil-btn${histFiltro===f.k?' active':''}" onclick="renderHistorial('${f.k}')">${f.l}</button>`
).join(’’);

const hoy = dKey();
const semana = new Date(); semana.setDate(semana.getDate() - 7);
let lista = […state.historial].reverse();
if (filtro === ‘hoy’) lista = lista.filter(h => h.fecha === hoy);
else if (filtro === ‘semana’) lista = lista.filter(h => new Date(h.fecha) >= semana);
else if (filtro.startsWith(‘mesa’)) { const m = parseInt(filtro.replace(‘mesa’,’’)); lista = lista.filter(h => h.mesa === m); }

const totalF = lista.reduce((s,h) => s+h.total, 0);
const promF = lista.length > 0 ? Math.round(totalF / lista.length) : 0;

const ventasHTML = lista.length === 0
? ‘<div class="empty-state"><div class="ei">📭</div><p>Sin ventas en este período</p></div>’
: lista.map((h, idx) => ` <div class="venta-card" onclick="toggleDetalle(${idx})"> <div class="venta-card-head"> <div><div class="venta-mesa-tag">Mesa ${h.mesa}</div><div class="venta-time">${h.fecha} · ${h.hora}</div></div> <div class="venta-monto">${fmt(h.total)}</div> </div> <div class="venta-desc">${h.items.length} producto(s) · toca para ver detalle</div> <div class="venta-detail" id="det-${idx}"> ${h.items.map(it=>`<div class="venta-detail-row"><span>${it.qty}× ${it.n}</span><span>${fmt(it.p*it.qty)}</span></div>`).join('')} </div> </div>`).join(’’);

$(‘histBody’).innerHTML = `<div class="hist-summary"> <div class="hsum-card"><div class="hsum-val">${lista.length}</div><div class="hsum-label">Cobros</div></div> <div class="hsum-card"><div class="hsum-val">${fmt(totalF)}</div><div class="hsum-label">Total</div></div> <div class="hsum-card"><div class="hsum-val">${fmt(promF)}</div><div class="hsum-label">Promedio</div></div> </div> ${ventasHTML}`;
}

function toggleDetalle(idx) {
const el = $(‘det-’+idx);
if (el) el.style.display = el.style.display === ‘block’ ? ‘none’ : ‘block’;
}

// ── CONFIGURACIÓN ────────────────────────────────────────────
function renderConfig(filtro=’’) {
const body = $(‘configBody’);
body.innerHTML = ‘’;
state.menu.forEach((cat, ci) => {
const items = filtro
? cat.items.filter(it => it.n.toLowerCase().includes(filtro.toLowerCase()))
: cat.items;
if (filtro && items.length === 0) return;

```
const div = document.createElement('div');
div.className = 'config-cat';
div.innerHTML = `<div class="config-cat-title">${cat.cat}</div>` +
  items.map(it => {
    const ii = cat.items.indexOf(it);
    return `<div class="config-item">
      <span class="config-item-name">${it.n}</span>
      <span class="config-item-price">${fmt(it.p)}</span>
      <button class="config-edit-btn" onclick="abrirEditar(${ci},${ii})">✏️ Editar</button>
    </div>`;
  }).join('') +
  // Only show "add" button for editable categories AND when no search filter
  (!filtro && cat.editable ? `
    <div class="config-add-row">
      <button class="config-add-btn" onclick="abrirNuevo(${ci})">+ Agregar producto a ${cat.cat.replace(/^.{1,2}\s/, '')}</button>
    </div>` : '');
body.appendChild(div);
```

});
}

function filtrarConfig(val) { renderConfig(val); }

// Edit existing
function abrirEditar(ci, ii) {
editandoCat = ci; editandoIdx = ii;
const it = state.menu[ci].items[ii];
$(‘editarSub’).textContent = state.menu[ci].cat;
$(‘editNombre’).value = it.n;
$(‘editPrecio’).value = it.p;
$(‘modalEditar’).classList.add(‘open’);
}

function guardarEdicion() {
const nombre = $(‘editNombre’).value.trim();
const precio = parseInt($(‘editPrecio’).value);
if (!nombre || isNaN(precio) || precio < 0) { showToast(‘⚠️ Datos inválidos’); return; }
state.menu[editandoCat].items[editandoIdx].n = nombre;
state.menu[editandoCat].items[editandoIdx].p = precio;
guardar();
cerrarModal(‘modalEditar’);
renderConfig($(‘configSearch’).value);
showToast(‘✅ Guardado’);
}

// Add new
function abrirNuevo(ci) {
nuevoCat = ci;
$(‘nuevoSub’).textContent = ’Categoría: ’ + state.menu[ci].cat;
$(‘nuevoNombre’).value = ‘’;
$(‘nuevoPrecio’).value = ‘’;
$(‘modalNuevo’).classList.add(‘open’);
}

function guardarNuevo() {
const nombre = $(‘nuevoNombre’).value.trim();
const precio = parseInt($(‘nuevoPrecio’).value);
if (!nombre || isNaN(precio) || precio < 0) { showToast(‘⚠️ Datos inválidos’); return; }
state.menu[nuevoCat].items.push({ n: nombre, p: precio });
guardar();
cerrarModal(‘modalNuevo’);
renderConfig();
showToast(‘✅ Producto agregado’);
}

// ── INIT ─────────────────────────────────────────────────────
irA(‘selector’);